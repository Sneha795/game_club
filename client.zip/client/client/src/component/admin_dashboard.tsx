function Admindashboard() {
    return (
        <div>
            <h1>Admin DashBoard</h1>
        </div>
    )
}

export default Admindashboard;